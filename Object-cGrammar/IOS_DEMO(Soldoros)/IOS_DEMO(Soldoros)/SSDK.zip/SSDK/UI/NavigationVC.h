//
//  NavigationViewController.h
//  西南交大-池增阳
//
//  Created by yy on 14-10-10.
//  Copyright (c) 2014年 Soldoros. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationVC : UINavigationController

@end
